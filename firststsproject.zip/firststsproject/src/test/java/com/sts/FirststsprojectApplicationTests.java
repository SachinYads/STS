package com.sts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirststsprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
