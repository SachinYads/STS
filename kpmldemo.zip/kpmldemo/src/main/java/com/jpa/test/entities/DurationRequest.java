package com.jpa.test.entities;

public class DurationRequest {
	 private String duration;

	    public String getDuration() {
	        return duration;
	    }

	    public void setDuration(String duration) {
	        this.duration = duration;
	    }
}
