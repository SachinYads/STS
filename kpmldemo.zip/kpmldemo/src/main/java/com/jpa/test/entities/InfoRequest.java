package com.jpa.test.entities;

public class InfoRequest {
	    private String service_name;
	    private String key;
		public String getService_name() {
			return service_name;
		}
		public void setService_name(String service_name) {
			this.service_name = service_name;
		}
		public String getKey() {
			return key;
		}
		public void setKey(String key) {
			this.key = key;
		}

	    // Add getter and setter methods
	    // ...
	}

