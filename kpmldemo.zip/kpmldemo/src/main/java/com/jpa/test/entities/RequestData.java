package com.jpa.test.entities;
public class RequestData {
    private String service_name;
    private String key;

    // Getters and setters for the properties

    // Constructor
    public RequestData(String service_name, String key) {
        this.service_name = service_name;
        this.key = key;
    }

	}
